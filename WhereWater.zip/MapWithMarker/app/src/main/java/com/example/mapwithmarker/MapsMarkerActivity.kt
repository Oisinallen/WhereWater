package com.example.mapwithmarker

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions


// [START maps_marker_on_map_ready]
class MapsMarkerActivity : AppCompatActivity(), OnMapReadyCallback {

    // [START_EXCLUDE]
    // [START maps_marker_get_map_async]
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Retrieve the content view that renders the map.
        setContentView(R.layout.activity_maps)

        // Get the SupportMapFragment and request notification when the map is ready to be used.
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as? SupportMapFragment
        mapFragment?.getMapAsync(this)
    }

    // [START maps_marker_on_map_ready_add_marker]
    override fun onMapReady(googleMap: GoogleMap) {
      val coordinates = LatLng(52.67328977852925, -8.570110651823667)
      googleMap.addMarker(
        MarkerOptions()
          .position(coordinates)
          .title("Marker Student Life")
      )
      googleMap.moveCamera(CameraUpdateFactory.newLatLng(coordinates))
    }

}

/**
 * A demo class that stores and retrieves data objects with each marker.
 */
class MarkerDemoActivity<OnMarkerClickListener> : AppCompatActivity(),
    OnMarkerClickListener, OnMapReadyCallback {
    private val Schrodinger = LatLng(-31.952854, 115.857342)
    private val PESS = LatLng(-33.87365, 151.20689)
    private val CS = LatLng(-27.47093, 153.0235)

    private var markerSchrodinger: Marker? = null
    private var markerPESS: Marker? = null
    private var markerCS: Marker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_markers)
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment!!.getMapAsync(this)
    }

    /** Called when the map is ready.  */
    override fun onMapReady(map: GoogleMap) {
        // Add some markers to the map, and add a data object to each marker.
        var markerLimerick = map.addMarker(
            MarkerOptions()
                .position(Schrodinger)
                .title("UL")
        )
        markerLimerick?.tag = 0
        markerLimerick = map.addMarker(
            MarkerOptions()
                .position(this.PESS)
                .title("UL")
        )
        markerLimerick?.tag = 0
        markerLimerick = map.addMarker(
            MarkerOptions()
                .position(CS)
                .title("UL")
        )
        // Set a listener for marker click.
        map.setOnMarkerClickListener(this)
    }

    /** Called when the user clicks a marker.  */
    fun onMarkerClick(marker: Marker): Boolean {

        // Retrieve the data from the marker.
        val clickCount = marker.tag as? Int

        // Check if a click count was set, then display the click count.
        clickCount?.let {
            val newClickCount = it + 1
            marker.tag = newClickCount
            Toast.makeText(
                this,
                "${marker.title} has been clicked $newClickCount times.",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Return false to indicate that we have not consumed the event and that we wish
        // for the default behavior to occur (which is for the camera to move such that the
        // marker is centered and for the marker's info window to open, if it has one).
        return false
    }
}

private fun <OnMarkerClickListener> Any.setOnMarkerClickListener(markerDemoActivity: MarkerDemoActivity<OnMarkerClickListener>) {

}

